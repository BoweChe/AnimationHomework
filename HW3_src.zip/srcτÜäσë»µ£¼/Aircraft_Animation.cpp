#include "Aircraft_Animation.h"


Aircraft_Animation::Aircraft_Animation()
{
	this->m_model_mat = glm::mat4(1.0f);
}


Aircraft_Animation::~Aircraft_Animation()
{
}

void Aircraft_Animation::init()
{
	reset();
}

void Aircraft_Animation::init(Curve* animation_curve)
{
	m_animation_curve = animation_curve;
    make_table();
	reset();//这里的reset赋值了m_model_mat;
}

void Aircraft_Animation::update(float delta_time)
{
    
    
    
    if(i<60*total_moving_time){
        m_model_mat = glm::translate(glm::mat4(1.0f),plane_pos[i]);
        i++;
    }else{
        reset();
    }
    
    
    
    
}


void Aircraft_Animation::reset()
{
	m_model_mat = glm::mat4(1.0f);

	if (m_animation_curve != nullptr && m_animation_curve->control_points_pos.size() > 0)
	{
		m_model_mat = glm::translate(m_model_mat, m_animation_curve->control_points_pos[0]);
	}
}

void Aircraft_Animation::make_table()
{
    int counter = total_moving_time*60;
    float velocity = 2.0/(t2-t1+1);
    
    float increment = 1.0/counter;
    float begin_time = 0.0;
    float tempanswer;
    for(int i=0;i<counter;i++){
        //std::cout<<begin_time<<std::endl;
        //begin_time =i*increment;
        if(begin_time<=t1){
            tempanswer = velocity*begin_time*begin_time/2/t1;
            table1.insert(table1.end(),tempanswer);
        }else if(begin_time>t1&&begin_time<t2){
            tempanswer = velocity*t1/2+velocity*(begin_time-t1);
            table1.insert(table1.end(),tempanswer);
        }else if(begin_time>t2){
            float te = (begin_time-t2)/(1-t2)/2;
            tempanswer = velocity*t1/2+velocity*(t2-t1)+velocity*(begin_time-t2)*(1-te);
            //tempanswer.setprecision(3);
            table1.insert(table1.end(),tempanswer);
        }
        //std::cout<<tempanswer<<std::endl;
        begin_time = begin_time+increment;
    }
    //std::cout<<table1.size()<<std::endl;
    //std::vector<float> table2;
    table2.insert(table2.end(),0.0);
    float lasttemp = 0.0f;
    for(int i=1;i<1600;i++){
        //std::cout<<table1[i]<<std::endl;
        float first_x = m_animation_curve->curve_points_pos[i-1][0];
        float first_y = m_animation_curve->curve_points_pos[i-1][1];
        float first_z = m_animation_curve->curve_points_pos[i-1][2];
        //
        float second_x = m_animation_curve->curve_points_pos[i][0];
        float second_y = m_animation_curve->curve_points_pos[i][1];
        float second_z = m_animation_curve->curve_points_pos[i][2];
        float tempans = pow(first_x-second_x,2)+pow(first_y-second_y,2)+pow(first_z-second_z,2);
        tempans = sqrt(tempans);
        lasttemp +=tempans;
        table2.insert(table2.end(),lasttemp);
        //std::cout<<lasttemp<<std::endl;
    }
    //normalize table2
    for(int i=0;i<1600;i++){
        table2[i]=table2[i]/table2[1599];
        
    }
    
    plane_pos.insert(plane_pos.end(),m_animation_curve->curve_points_pos[0]);
    int j = 0;
    int count =0;
    int size = table2.size();
    for(int i=1;i<table1.size();i++){
        for(int j=1;j<table2.size();j++){
            if(table1[i]>table2[j-1]&&table1[i]<table2[j]){
                float frc = (table1[i]-table2[j-1])/(table2[j]-table2[j-1]);
                float planeX = (1-frc)*m_animation_curve->curve_points_pos[j-1][0]+frc*m_animation_curve->curve_points_pos[j][0];
                float planeY = (1-frc)*m_animation_curve->curve_points_pos[j-1][1]+frc*m_animation_curve->curve_points_pos[j][1];
                float planeZ = (1-frc)*m_animation_curve->curve_points_pos[j-1][2]+frc*m_animation_curve->curve_points_pos[j][2];
                glm::vec3 point = {planeX,planeY,planeZ};
                plane_pos.insert(plane_pos.end(),point);
                count++;
            }
        }
    }
    std::cout<<count<<std::endl;
    /*
    for(int i=1;i<table1.size();i++){
        for(int j=size-1;j>=0;j--){
            if(table1[i]>=table2[j]){
                plane_pos.insert(plane_pos.end(),m_animation_curve->curve_points_pos[j]);
                //std::cout<<j<<std::endl;
                count++;
                break;
            }
        }
        std::cout<<count<<std::endl;
        std::cout<<plane_pos.size()<<std::endl;
        
    }
    */
    
    for(int i=0;i<600;i++){
        std::cout<<table1[i]<<std::endl;
    }
    
     
    

}



void Aircraft_Animation::clear_table(){
    i=0;
    //std::cout<<t1<<std::endl;
    table1 = {};
    table2 = {};
    plane_pos = {};
    
    
}
